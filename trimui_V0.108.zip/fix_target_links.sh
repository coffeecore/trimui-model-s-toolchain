cd $1
ln -s ./lib/libSDL_mixer-1.2.so.0.12.0 ./lib/libSDL_mixer-1.2.so.0
ln -s ./lib/libSDL-1.2.so.0.11.4 ./lib/libSDL-1.2.so.0
ln -s ./lib/libSDL2_image-2.0.so.0.0.1 ./lib/libSDL2_image-2.0.so.0
ln -s ./lib/libSDL_image-1.2.so.0.8.4 ./lib/libSDL_image-1.2.so.0
ln -s ./lib/libSDL2-2.0.so.0.9.0 ./lib/libSDL2-2.0.so.0
ln -s ./lib/libSDL2_mixer-2.0.so.0.0.1 ./lib/libSDL2_mixer-2.0.so.0
ln -s ./lib/libSDL_net-1.2.so.0.8.0 ./lib/libSDL_net-1.2.so.0
ln -s ./lib/libSDL_ttf-2.0.so.0.10.1 ./lib/libSDL_ttf-2.0.so.0
